package com.fridayapp.attendancetracker.network;


import com.example.admin.quiz.model.User;
import com.example.admin.quiz.model.UserList;
import com.example.admin.quiz.model.Questions;
import com.fridayapp.attendancetracker.model.UserList;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;


public interface RetrofitInterface {


    @GET("admin/quiz/question_api.php")
    public Call<List<Questions>> getQuestions();

    @FormUrlEncoded
    @POST("admin/quiz/user_registration.php")
    public Call<ResponseBody> registerUser(@Field("name") String name,
                                           @Field("email") String password,
                                           @Field("password") String email, @Field("image") String image);

    @GET("admin/quiz/getAllUser.php")
    Call<UserList> getAllUser();

    @GET("admin/quiz/getUser.php")
    Call<User> getUserById(@Query("id") Integer id);

    @FormUrlEncoded
    @POST("admin/quiz/updateUser.php")
    public Call<ResponseBody> updateUser(@Field("id") Integer id,
                                         @Field("name") String password,
                                         @Field("image") String image);

    @FormUrlEncoded
    @POST("admin/quiz/updatePasswordUser.php")
    public Call<ResponseBody> updatePasswordUser(@Field("id") Integer id,
                                                 @Field("password") String password
    );

    @GET("admin/quiz/deleteUser.php")
    Call<ResponseBody> deleteUser(@Query("id") Integer id);
}
