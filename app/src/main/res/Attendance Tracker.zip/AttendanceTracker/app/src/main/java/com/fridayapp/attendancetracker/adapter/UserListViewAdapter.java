package com.fridayapp.attendancetracker.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import androidx.fragment.app.FragmentActivity;

import com.fridayapp.attendancetracker.R;
import com.fridayapp.attendancetracker.model.User;
import com.fridayapp.attendancetracker.network.Config;
import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class UserListViewAdapter extends BaseAdapter {
    private static LayoutInflater inflater = null;
    private Context mContext;
    private List<User> listUser = new ArrayList<User>();

    public UserListViewAdapter(FragmentActivity activity, List<User> listUser) {
        mContext = activity;
        this.listUser = listUser;
        inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return listUser.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public class ViewHolder {
        TextView tvUserName;
        ImageView imgUserPic;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder;

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_list_user, null);
            viewHolder = new ViewHolder();
            viewHolder.tvUserName = convertView.findViewById(R.id.tvUserNameListName);
            viewHolder.imgUserPic = convertView.findViewById(R.id.imgProfileListItem);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.tvUserName.setText(listUser.get(position).getName());
        Picasso.get()
                .load(Config.URL_IMAGES + listUser.get(position).getImage())
                .memoryPolicy(MemoryPolicy.NO_CACHE)
                .networkPolicy(NetworkPolicy.NO_CACHE)
                .into(viewHolder.imgUserPic);

        return convertView;
    }

}
