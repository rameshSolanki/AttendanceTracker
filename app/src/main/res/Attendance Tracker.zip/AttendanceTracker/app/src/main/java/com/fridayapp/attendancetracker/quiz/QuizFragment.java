package com.fridayapp.attendancetracker.quiz;

import android.app.ProgressDialog;
import android.os.Bundle;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.fridayapp.attendancetracker.R;
import com.fridayapp.attendancetracker.model.Questions;
import com.fridayapp.attendancetracker.network.ApiUtil;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class QuizFragment extends Fragment {
    String question, opta, optb, optc, optd, ans="";
    int score = 0;
    int qid = 0;
    Questions currentQ;
    TextView txtQuestion;
    RadioButton rda, rdb, rdc, rdd;
    Button butNext;
    List<Questions> quesList;
    private ProgressDialog pDialog;
    LinearLayout linearLayout;

    @Override
    @Nullable
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_quiz, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getActivity().setTitle("Questions");
        linearLayout = getActivity().findViewById(R.id.linearLyaout);
        fetchQuestions();

    }


    private void fetchQuestions() {
        linearLayout.setVisibility(View.INVISIBLE);
        pDialog = new ProgressDialog(getContext());
        pDialog.setMessage("Loading");
        pDialog.setCancelable(true);
        pDialog.show();
        ApiUtil.getServiceClass().getQuestions().enqueue(new Callback<List<Questions>>() {
            @Override
            public void onResponse(Call<List<Questions>> call, Response<List<Questions>> response) {
                pDialog.dismiss();

                if (response.isSuccessful()) {
                    quesList = response.body();

                    Toast.makeText(getActivity(), "Returned count " + quesList.size(), Toast.LENGTH_SHORT).show();
                    takeAction();
                }
            }

            @Override
            public void onFailure(Call<List<Questions>> call, Throwable t) {
                //showErrorMessage();
                Toast.makeText(getActivity(), "error loading" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }


    private void setQuestionView() {
        txtQuestion.setText(currentQ.getQuestion());
        rda.setText(currentQ.getOptA());
        rdb.setText(currentQ.getOptB());
        rdc.setText(currentQ.getOptC());
        rdd.setText(currentQ.getOptD());
        qid++;
    }

    public void takeAction() {
        linearLayout.setVisibility(View.VISIBLE);
        currentQ = quesList.get(qid);
        txtQuestion = getActivity().findViewById(R.id.textView1);
        rda = getActivity().findViewById(R.id.radio0);
        rdb = getActivity().findViewById(R.id.radio1);
        rdc = getActivity().findViewById(R.id.radio2);
        rdd = getActivity().findViewById(R.id.radio3);
        butNext = getActivity().findViewById(R.id.button1);
        setQuestionView();

        butNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RadioGroup grp = getActivity().findViewById(R.id.radioGroup1);

                if (grp.getCheckedRadioButtonId() == -1) {
                    return;
                }

                RadioButton answer = getActivity().findViewById(grp.getCheckedRadioButtonId());

                grp.clearCheck();
                if (currentQ.getAnswer().equals(answer.getText())) {
                    score++;
                    Log.d("score", "Your score" + score);
                }
                if (qid < 5) {

                    currentQ = quesList.get(qid);
                    setQuestionView();
                    if (qid == 5) {
                        butNext.setText("Submit"); }
                } else {
                    FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
                    Bundle b = new Bundle();
                    b.putInt("score", score);
                    b.putString("ans1", currentQ.getAnswer());

                    ResultFragment resultFragment = new ResultFragment();
                    fragmentTransaction.replace(R.id.main_content, b);
                    fragmentTransaction.commit();


                }
            }
        });
    }

}
