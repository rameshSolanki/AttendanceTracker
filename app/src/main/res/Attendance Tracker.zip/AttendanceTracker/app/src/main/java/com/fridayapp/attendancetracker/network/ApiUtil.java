package com.fridayapp.attendancetracker.network;


public class ApiUtil {
    public static final String BASE_URL = "https://app0209.000webhostapp.com/file_manage/";

    public static RetrofitInterface getServiceClass() {
        return RetrofitAPI.getRetrofit(BASE_URL).create(RetrofitInterface.class);
    }

}
