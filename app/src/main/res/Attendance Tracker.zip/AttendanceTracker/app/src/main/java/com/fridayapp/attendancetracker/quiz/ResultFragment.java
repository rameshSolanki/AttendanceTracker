package com.fridayapp.attendancetracker.quiz;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.fridayapp.attendancetracker.R;


public class ResultFragment extends Fragment {
    RatingBar bar;
    TextView t, t1;

    @Override
    @Nullable
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_result, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getActivity().setTitle("Result");
        bar = getActivity().findViewById(R.id.ratingBar1);
        bar.setNumStars(5);
        bar.setStepSize(0.5f);
        t = getActivity().findViewById(R.id.textResult);
        t1 = getActivity().findViewById(R.id.textResult1);

        Bundle b = getActivity().getIntent().getExtras();
        int score = getArguments().getInt("score");
        String ans = getArguments().getString("ans1");

        t1.setText("ans - " + ans);

        bar.setRating(score);

        switch (score) {
            case 0:
                t.setText("You scored 0%");
                break;
            case 1:
                t.setText("You have 20%");
                break;
            case 2:
                t.setText("You have 40%");
                break;
            case 3:
                t.setText("You have 60%");
                break;
            case 4:
                t.setText("You have 80%");
                break;
            case 5:
                t.setText(" you have 100%");
                break;
        }
    }
}